"""
Views for Users app.
"""
from django.contrib.auth import get_user_model
from rest_framework import generics, permissions, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from django.shortcuts import get_object_or_404
from .serializers import UserRoleUpdateSerializer
from .serializers import UserCreateSerializer, UserSerializer, VerifyOTPSerializer, ForgotPasswordSerializer, SetNewPasswordSerializer, AuthenticatedResetPasswordSerializer
import random
import uuid
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from datetime import timedelta
from .models import PasswordResetOTP
User = get_user_model()


class RegisterView(generics.CreateAPIView):
    """
    Register a new user.
    """
    queryset = User.objects.all()
    serializer_class = UserCreateSerializer
    permission_classes = [permissions.AllowAny]

class IsAdminRole(permissions.BasePermission):
    """
    Allows access only to users with the 'admin' role.
    """
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'admin')

class UserCreateView(generics.CreateAPIView):
    """
    Admin-only view to create new users/employees.
    Only users with is_staff/is_superuser can access this.
    """
    queryset = User.objects.all()
    serializer_class = UserCreateSerializer
    # Change permission from AllowAny to IsAdminUser
    permission_classes = [IsAdminRole]

class MeView(APIView):
    """
    Get current user profile.
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)
    
    def patch(self, request):
        serializer = UserSerializer(request.user, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

class IsAdminRole(permissions.BasePermission):
    """
    Allows access only to users with the 'admin' role.
    """
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'admin')
class UserListView(generics.ListAPIView):
    """
    List all users (for assignments, etc.)
    """
    queryset = User.objects.filter(is_active=True)
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    search_fields = ["username", "email", "first_name", "last_name"]

class ChangeUserRoleView(APIView):
    """
    Endpoint to change a user's role with strict hierarchy rules.
    """
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def patch(self, request, user_id):
        user = request.user
        target_user = get_object_or_404(User, id=user_id)
        new_role = request.data.get('role')

        # 1. SECURITY: Prevent any user from changing their own role
        if user.id == target_user.id:
            return Response(
                {"detail": "You cannot change your own role."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # 2. MANAGER RESTRICTIONS
        if user.role == User.Role.MANAGER:
            # A. Prevent Managers from touching Admins or other Managers
            if target_user.role in [User.Role.ADMIN, User.Role.MANAGER]:
                return Response(
                    {"detail": "Managers cannot change roles for Admins or other Managers."},
                    status=status.HTTP_403_FORBIDDEN
                )
            
            # B. Limit allowed role transitions (only Viewer <-> Annotator)
            allowed_manager_roles = [User.Role.ANNOTATOR, User.Role.VIEWER]
            if new_role not in allowed_manager_roles:
                return Response(
                    {"detail": "Managers can only assign Annotator or Viewer roles."},
                    status=status.HTTP_403_FORBIDDEN
                )

        # 3. ADMIN CHECK: If not Admin and failed Manager check, deny access
        elif user.role != User.Role.ADMIN:
            return Response(
                {"detail": "Only Admins and Managers can change user roles."},
                status=status.HTTP_403_FORBIDDEN
            )

        # 4. PERFORM UPDATE
        serializer = UserRoleUpdateSerializer(target_user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({
                "message": f"Role for {target_user.username} updated to {new_role}",
                "user": serializer.data
            }, status=status.HTTP_200_OK)
            
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class UserDeleteView(generics.DestroyAPIView):
    """
    Admin-only view to delete a user.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser] # Ensures only Staff/Superusers access this
    lookup_field = 'id'

    def delete(self, request, *args, **kwargs):
        user_to_delete = self.get_object()
        
        # Security check: Prevent self-deletion
        if request.user.id == user_to_delete.id:
            return Response(
                {"detail": "You cannot delete your own admin account."},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        return super().delete(request, *args, **kwargs)
    
class ForgotPasswordView(APIView):
    """Step 1: Send OTP to Email"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        
        user = User.objects.filter(email=email).first()
        if user:
            # Generate 4-digit OTP
            otp = str(random.randint(1000, 9999))
            expiry = timezone.now() + timedelta(minutes=10)
            
            # Delete old OTPs for this user and save new one
            PasswordResetOTP.objects.filter(user=user).delete()
            PasswordResetOTP.objects.create(
                user=user,
                otp_hash=PasswordResetOTP.hash_otp(otp),
                expires_at=expiry
            )

            # Send Email
            send_mail(
                'Your Password Reset OTP',
                f'Your OTP is {otp}. It expires in 10 minutes.',
                settings.DEFAULT_FROM_EMAIL,
                [email],
                fail_silently=False,
            )

        # Return 200 regardless of user existence for security (prevent email enumeration)
        return Response({"detail": "If this email is registered, an OTP has been sent."}, status=status.HTTP_200_OK)

class VerifyOTPView(APIView):
    """Step 2: Verify OTP and return a temporary reset token"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        email = serializer.validated_data['email']
        otp = serializer.validated_data['otp']
        hashed_otp = PasswordResetOTP.hash_otp(otp)

        otp_record = PasswordResetOTP.objects.filter(
            user__email=email, 
            otp_hash=hashed_otp
        ).first()

        if not otp_record or otp_record.is_expired():
            return Response({"detail": "Invalid or expired OTP."}, status=status.HTTP_400_BAD_REQUEST)

        # OTP is valid: mark as verified and generate a unique temporary token
        otp_record.is_verified = True
        reset_token = str(uuid.uuid4())
        otp_record.token = reset_token  # Ensure you've added this field to your model
        otp_record.save()

        return Response({
            "detail": "OTP verified. Use the reset_token to set a new password.",
            "reset_token": reset_token
        }, status=status.HTTP_200_OK)

class SetNewPasswordView(APIView):
    """Step 3: Update password using verified reset_token"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = SetNewPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data['email']
        reset_token = serializer.validated_data['reset_token'] # Match serializer field

        # Query using the token instead of the otp
        otp_record = PasswordResetOTP.objects.filter(
            user__email=email, 
            token=reset_token, # This field must exist in your model
            is_verified=True
        ).first()

        if not otp_record or otp_record.is_expired():
            return Response({"detail": "Invalid or expired reset token."}, status=status.HTTP_400_BAD_REQUEST)

        # Update the user's password
        user = otp_record.user
        user.set_password(serializer.validated_data['password'])
        user.save()
        
        # Burn the record so it can't be used again
        otp_record.delete()
        
        return Response({"detail": "Password has been reset successfully."}, status=status.HTTP_200_OK)

class AuthenticatedResetPasswordView(APIView):
    """
    Reset password for logged-in users.
    No OTP required. Requires username, old password, and new password.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = AuthenticatedResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        user = request.user
        validated_data = serializer.validated_data

        # 1. Security Check: Verify the username matches the authenticated user
        if user.username != validated_data['username']:
            return Response(
                {"detail": "Username does not match the authenticated session."}, 
                status=status.HTTP_403_FORBIDDEN
            )

        # 2. Verify old password
        if not user.check_password(validated_data['old_password']):
            return Response(
                {"old_password": ["Incorrect old password."]}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        # 3. Update to the new hashed password
        user.set_password(validated_data['new_password'])
        user.save()

        return Response(
            {"detail": "Password has been updated successfully."}, 
            status=status.HTTP_200_OK
        )